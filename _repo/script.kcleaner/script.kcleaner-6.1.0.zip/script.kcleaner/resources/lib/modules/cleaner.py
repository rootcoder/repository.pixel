import xbmcvfs
import xbmcaddon
import xbmc

import shutil
import os


addon_name = "script.kcleaner"
addon_id = xbmcaddon.Addon(id=addon_name)
thumbnail_path = xbmcvfs.translatePath("special://thumbnails")
database_path = xbmcvfs.translatePath("special://database")
cache_path = os.path.join(xbmcvfs.translatePath("special://home"), "cache")
thumbs = xbmcvfs.translatePath(os.path.join("special://home/userdata/Thumbnails", ""))
temp_path = xbmcvfs.translatePath("special://temp")
addon_path = xbmcvfs.translatePath(addon_id.getAddonInfo("path"))
media_path = os.path.join(addon_path, "media")
icon_path = xbmcvfs.translatePath(
    os.path.join(f"special://home/addons/{addon_name}", "icon.png")
)


def get_image(id):
    return os.path.join(media_path, id)


def clean_thumb():
    if os.path.exists(thumbnail_path) == True:
        for root, dirs, files in os.walk(thumbnail_path):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                for f in files:
                    try:
                        os.unlink(os.path.join(root, f))
                    except:
                        pass
    if os.path.exists(thumbs):
        try:
            for root, dirs, files in os.walk(thumbs):
                file_count = 0
                file_count += len(files)
                # Count files and give option to delete
                if file_count > 0:
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
        except:
            pass

    try:
        text13 = os.path.join(database_path, "Textures13.db")
        os.unlink(text13)
    except:
        pass
    xbmc.executebuiltin(f"Notification(KCleaner,Thumbs removidas,5000,{icon_path})")


def clean_cache():
    xbmc.log(cache_path, xbmc.LOGINFO)
    xbmc.log(temp_path, xbmc.LOGINFO)
    if os.path.exists(cache_path) == True:
        for root, dirs, files in os.walk(cache_path):
            file_count = 0
            file_count += len(files)
            if file_count > 0:

                for f in files:
                    try:
                        if (
                            f == "kodi.log"
                            or f == "kodi.old.log"
                            or f == "archive_cache"
                            or f == "commoncache.db"
                            or f == "commoncache.socket"
                            or f == "temp"
                        ):
                            continue
                        os.unlink(os.path.join(root, f))
                    except:
                        pass
                for d in dirs:
                    try:
                        if d == "archive_cache" or d == "temp":
                            continue
                        shutil.rmtree(os.path.join(root, d))
                    except:
                        pass

            else:
                pass

    if os.path.exists(temp_path) == True:
        for root, dirs, files in os.walk(temp_path):
            file_count = 0
            file_count += len(files)
            if file_count > 0:

                for f in files:
                    try:
                        if (
                            f == "kodi.log"
                            or f == "kodi.old.log"
                            or f == "archive_cache"
                            or f == "commoncache.db"
                            or f == "commoncache.socket"
                            or f == "temp"
                        ):
                            continue
                        os.unlink(os.path.join(root, f))
                    except:
                        pass
                for d in dirs:
                    try:
                        if d == "archive_cache" or d == "temp":
                            continue
                        shutil.rmtree(os.path.join(root, d))
                    except:
                        pass

            else:
                pass

    xbmc.executebuiltin(f"Notification(KCleaner,Cache removidos,5000,{icon_path})")


def clean_packages():
    package_path = xbmcvfs.translatePath("special://home/addons/packages")
    for root, dirs, files in os.walk(package_path):
        file_count = 0
        file_count += len(files)
        if file_count > 0:
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
    xbmc.executebuiltin(f"Notification(KCleaner,Pacotes removidos,5000,{icon_path})")
